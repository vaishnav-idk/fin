import UINotFound from "@/ui/layout/not-found";

export default async function NotFound() {
  return (
    <>
      <UINotFound />
    </>
  );
}
