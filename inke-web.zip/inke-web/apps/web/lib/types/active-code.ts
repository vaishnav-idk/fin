export interface ActiveCodeItem {
  id: string;
  userId: string;
  code: string;
  expires: string;
  createdAt: string;
  updatedAt: string;
}
